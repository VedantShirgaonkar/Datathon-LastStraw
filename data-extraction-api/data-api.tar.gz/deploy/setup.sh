#!/bin/bash
# ===========================================
# Amazon Linux 2023 / 2 Server Setup Script
# ===========================================

set -e  # Exit on error

echo "=========================================="
echo "  Data Extraction API - Server Setup"
echo "  Target: Amazon Linux (ec2-user)"
echo "=========================================="

# Update system
echo "[1/7] Updating system packages..."
sudo yum update -y

# Install Python and dependencies
echo "[2/7] Installing Python, Git, Nginx..."
sudo yum install -y python3 python3-pip git nginx acl

# Check python version
python3 --version

# Create app directory
echo "[3/7] Setting up application directory..."
APP_DIR="/home/ec2-user/data-extraction-api"
# Ensure directory exists if we are running from inside it
mkdir -p $APP_DIR

# Create virtual environment
echo "[4/7] Creating Python virtual environment..."
cd $APP_DIR
python3 -m venv venv
source venv/bin/activate

# Install Python packages
echo "[5/7] Installing Python packages..."
pip install --upgrade pip
pip install -r requirements.txt

# Setup systemd service
echo "[6/7] Configuring systemd service..."
sudo cp deploy/data-api.service /etc/systemd/system/
# Update service file to use ec2-user if needed (sed replacement)
sudo sed -i 's/User=ubuntu/User=ec2-user/g' /etc/systemd/system/data-api.service
sudo sed -i 's/Group=ubuntu/Group=ec2-user/g' /etc/systemd/system/data-api.service
sudo sed -i 's|/home/ubuntu/|/home/ec2-user/|g' /etc/systemd/system/data-api.service

sudo systemctl daemon-reload
sudo systemctl enable data-api
sudo systemctl restart data-api

# Setup nginx
echo "[7/7] Configuring nginx..."
# Amazon Linux nginx config is slightly different
sudo cp deploy/nginx.conf /etc/nginx/conf.d/data-api.conf
# Remove default server if it exists
sudo mv /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
# Create a basic nginx.conf to include conf.d
echo 'user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {
    log_format  main  '"'"'$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"'"'"';

    access_log  /var/log/nginx/access.log  main;

    sendfile            on;
    tcp_nopush          on;
    tcp_nodelay         on;
    keepalive_timeout   65;
    types_hash_max_size 4096;

    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;

    include /etc/nginx/conf.d/*.conf;
}' | sudo tee /etc/nginx/nginx.conf

sudo systemctl enable nginx
sudo systemctl restart nginx

echo ""
echo "=========================================="
echo "  ✅ Deployment Complete!"
echo "=========================================="
echo ""
echo "Your API is now running at:"
echo "  http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)"
