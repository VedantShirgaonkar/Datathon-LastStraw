# EC2 Deployment Guide

## Quick Deploy Steps

### 1. Launch EC2 Instance (AWS Console)

1. Go to **AWS Console** → **EC2** → **Launch Instance**
2. Settings:
   - **Name**: `data-extraction-api`
   - **AMI**: Ubuntu Server 22.04 LTS
   - **Instance type**: `t2.micro` (Free tier)
   - **Key pair**: Create new → Download `.pem` file
   - **Security Group**: Allow ports 22, 80, 443

3. Launch and note the **Public IP**

### 2. Upload Code to EC2

```bash
# From your local machine (in data-extraction-api folder)
chmod 400 ~/Downloads/your-key.pem

# Upload the entire app
scp -i ~/Downloads/your-key.pem -r . ubuntu@<EC2_IP>:~/data-extraction-api/
```

### 3. Connect and Run Setup

```bash
# SSH into EC2
ssh -i ~/Downloads/your-key.pem ubuntu@<EC2_IP>

# Run the setup script
cd ~/data-extraction-api
chmod +x deploy/setup.sh
./deploy/setup.sh
```

### 4. Configure .env on EC2

```bash
nano ~/data-extraction-api/.env
# Add your credentials, then Ctrl+X, Y, Enter

# Restart the service
sudo systemctl restart data-api
```

### 5. Test

```bash
curl http://<EC2_IP>/health
```

## Webhook URLs

After deployment, configure your webhooks:

- **GitHub**: `http://<EC2_IP>/webhooks/github`
- **Jira**: `http://<EC2_IP>/webhooks/jira`

## Useful Commands

```bash
# Check service status
sudo systemctl status data-api

# View logs
sudo journalctl -u data-api -f

# Restart service
sudo systemctl restart data-api
```
