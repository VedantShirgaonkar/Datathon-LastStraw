# Schemas package
from .responses import HealthResponse, ErrorResponse

__all__ = ["HealthResponse", "ErrorResponse"]
